from flask import Flask, request, render_template, redirect, url_for, session, jsonify, flash
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from database import db 

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app = Flask(__name__)
app.secret_key = "s3cr3t_k3y"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5 MB por foto

# ----------------------
# Funciones auxiliares
# ----------------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ----------------------
# Rutas
# ----------------------

@app.route("/agregar", methods=["GET", "POST"])
def agregar():
    if request.method == "POST":
        errores = []

        # Datos del formulario
        region = request.form.get("select-region")
        comuna = request.form.get("select-commune")
        sector = request.form.get("black-sector")
        nombre = request.form.get("name")
        email = request.form.get("email")
        telefono = request.form.get("telefono")
        tipo = request.form.get("tipe")
        cantidad = request.form.get("amount")
        edad = request.form.get("age")
        unidad = request.form.get("ageUnit")
        fecha_entrega = request.form.get("deliveryDate")
        descripcion = request.form.get("description")

        # Validaciones básicas
        if not nombre or len(nombre.strip()) < 3:
            errores.append("Nombre inválido")
        if not email or len(email) < 5 or "@" not in email:
            errores.append("Email inválido")
        if telefono and not telefono.startswith("+569."):
            errores.append("Teléfono inválido")
        if not region:
            errores.append("Región requerida")
        if not comuna:
            errores.append("Comuna requerida")
        if not tipo:
            errores.append("Tipo de mascota requerido")
        if not cantidad or int(cantidad) < 1:
            errores.append("Cantidad inválida")
        if not edad or int(edad) < 1:
            errores.append("Edad inválida")
        if not unidad:
            errores.append("Unidad de edad requerida")
        if not fecha_entrega:
            errores.append("Fecha de entrega requerida")

        # Fotos
        fotos = request.files.getlist("fotos[]")
        if not fotos or len(fotos) == 0:
            errores.append("Se requiere al menos una foto")
        for f in fotos:
            if not allowed_file(f.filename):
                errores.append(f"Archivo no permitido: {f.filename}")

        # Contactos opcionales
        contactos = {}
        for medio in ["whatsapp", "telegram", "x", "instagram", "tiktok", "otra"]:
            valor = request.form.get(f"contacto_{medio}")
            if valor:
                contactos[medio] = valor

        if errores:
            return render_template("Agregar.html", errores=errores, data=request.form)

        # Guardar fotos
        filenames = []
        for f in fotos:
            filename = secure_filename(f.filename)
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            filenames.append(filename)

        # Insertar en BD
        try:
            db.insert_aviso_adopcion(
                region_id=region,
                comuna_id=comuna,
                sector=sector,
                nombre=nombre,
                email=email,
                celular=telefono,
                tipo=tipo,
                cantidad=int(cantidad),
                edad=int(edad),
                unidad_medida="m" if unidad.lower() == "meses" else "a",
                fecha_entrega=fecha_entrega,
                descripcion=descripcion,
                contactos=contactos,
                fotos=filenames
            )
            flash("Aviso agregado correctamente", "success")
            return redirect(url_for("portada"))
        except Exception as e:
            errores.append(str(e))
            return render_template("Agregar.html", errores=errores, data=request.form)

    # GET
    return render_template("Agregar.html")


@app.route("/avisos")
def avisos():
    page = int(request.args.get("page", 1))
    limit = 5
    offset = (page - 1) * limit
    avisos_list = db.get_avisos(limit=limit, offset=offset)
    return render_template("Avisos.html", avisos=avisos_list, page=page)


@app.route("/avisos/detalle/<int:aviso_id>")
def aviso_detalle(aviso_id):
    detalle = db.get_aviso_detalle(aviso_id)
    if detalle:
        return jsonify(detalle)
    return jsonify({"error": "Aviso no encontrado"}), 404


@app.route("/estadisticas")
def estadisticas():
    return render_template("Estadisticas.html")

@app.route("/")
@app.route("/portada")
def portada():
    avisos = db.get_last_5_avisos()
    return render_template("Portada.html", avisos=avisos)


# ----------------------
# Inicio de app
# ----------------------
if __name__ == "__main__":
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(debug=True)
