import pymysql
from datetime import datetime

# --- Configuración de la BD ---
DB_NAME = "tarea2"
DB_USERNAME = "cc5002"
DB_PASSWORD = "programacionweb"
DB_HOST = "localhost"
DB_PORT = 3306
DB_CHARSET = "utf8"

# --- Conexión ---
def get_conn():
    return pymysql.connect(
        db=DB_NAME,
        user=DB_USERNAME,
        passwd=DB_PASSWORD,
        host=DB_HOST,
        port=DB_PORT,
        charset=DB_CHARSET,
        cursorclass=pymysql.cursors.DictCursor
    )

# ----------------------
# Funciones de lectura
# ----------------------

def get_comuna_nombre_by_id(comuna_id):
    if not comuna_id:
        return None
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT nombre FROM comuna WHERE id=%s", (comuna_id,))
            row = cur.fetchone()
            return row["nombre"] if row else None
    finally:
        conn.close()

def get_fotos_by_aviso(aviso_id):
    if not aviso_id:
        return []
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("""SELECT CONCAT(ruta_archivo, nombre_archivo) AS foto
                           FROM foto WHERE aviso_id=%s ORDER BY id ASC""", (aviso_id,))
            rows = cur.fetchall()
            fotos = [r["foto"] for r in rows] if rows else []
            # quitar "static/" si existe
            fotos = [f[len("static/"):] if f.startswith("static/") else f for f in fotos]
            return fotos
    finally:
        conn.close()

def get_last_5_avisos():
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT a.id, a.fecha_ingreso, a.comuna_id, a.sector, a.cantidad,
                       a.tipo, a.edad, a.unidad_medida, a.nombre
                FROM aviso_adopcion a
                ORDER BY a.fecha_ingreso DESC
                LIMIT 5
            """)
            rows = cur.fetchall()
    finally:
        conn.close()

    avisos = []
    for r in rows:
        comuna = get_comuna_nombre_by_id(r["comuna_id"])
        fotos = get_fotos_by_aviso(r["id"])
        unidad = "meses" if r["unidad_medida"] == "m" else "años"
        edad_str = f"{r['edad']} {unidad}"
        avisos.append({
            "id": r["id"],
            "fecha_publicacion": r["fecha_ingreso"].strftime("%Y/%m/%d") if isinstance(r["fecha_ingreso"], datetime) else r["fecha_ingreso"],
            "hora_publicacion": r["fecha_ingreso"].strftime("%H:%M") if isinstance(r["fecha_ingreso"], datetime) else "",
            "comuna": comuna,
            "sector": r["sector"],
            "cantidad": r["cantidad"],
            "tipo": r["tipo"],
            "edad": edad_str,
            "nombre": r["nombre"],
            "foto": fotos[0] if fotos else None
        })
    return avisos

def get_avisos(limit=5, offset=0):
    conn = get_conn()
    avisos = []
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT * FROM aviso_adopcion
                ORDER BY fecha_ingreso DESC
                LIMIT %s OFFSET %s
            """, (limit, offset))
            rows = cur.fetchall()
    finally:
        conn.close()

    for r in rows:
        comuna = get_comuna_nombre_by_id(r["comuna_id"])
        fotos = get_fotos_by_aviso(r["id"])
        unidad = "meses" if r["unidad_medida"] == "m" else "años"
        edad_str = f"{r['edad']} {unidad}"
        avisos.append({
            "id": r["id"],
            "fecha_ingreso": r["fecha_ingreso"].strftime("%Y-%m-%d") if isinstance(r["fecha_ingreso"], datetime) else r["fecha_ingreso"],
            "fecha_entrega": r["fecha_entrega"].strftime("%Y-%m-%d") if isinstance(r["fecha_entrega"], datetime) else r["fecha_entrega"],
            "comuna": comuna,
            "sector": r["sector"],
            "cantidad": r["cantidad"],
            "tipo": r["tipo"],
            "edad": edad_str,
            "nombre": r["nombre"],
            "email": r["email"],
            "celular": r["celular"],
            "fotos": fotos
        })
    return avisos

def get_aviso_detalle(aviso_id):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM aviso_adopcion WHERE id=%s", (aviso_id,))
            r = cur.fetchone()
            if not r:
                return None
            comuna = get_comuna_nombre_by_id(r["comuna_id"])
            fotos = get_fotos_by_aviso(aviso_id)
            unidad = "meses" if r["unidad_medida"] == "m" else "años"
            edad_str = f"{r['edad']} {unidad}"
            return {
                "id": r["id"],
                "fecha_ingreso": r["fecha_ingreso"].strftime("%Y-%m-%d") if isinstance(r["fecha_ingreso"], datetime) else r["fecha_ingreso"],
                "fecha_entrega": r["fecha_entrega"].strftime("%Y-%m-%d") if isinstance(r["fecha_entrega"], datetime) else r["fecha_entrega"],
                "comuna": comuna,
                "sector": r["sector"],
                "cantidad": r["cantidad"],
                "tipo": r["tipo"],
                "edad": edad_str,
                "nombre": r["nombre"],
                "email": r["email"],
                "celular": r["celular"],
                "fotos": fotos
            }
    finally:
        conn.close()

def insert_aviso_adopcion(region_id, comuna_id, sector, nombre, email, celular,
                          tipo, cantidad, edad, unidad_medida, fecha_entrega,
                          descripcion, contactos, fotos):
    """
    Inserta un nuevo aviso en la base de datos.
    - contactos: dict {medio: valor} (opcional)
    - fotos: lista de nombres de archivo ya guardados
    """
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            # Insertar aviso principal
            cur.execute("""INSERT INTO aviso_adopcion
                           (fecha_ingreso, fecha_entrega, comuna_id, sector, cantidad,
                            tipo, edad, unidad_medida, descripcion, nombre, email, celular)
                           VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                        (fecha_entrega, comuna_id, sector, cantidad, tipo, edad,
                         unidad_medida, descripcion, nombre, email, celular))
            aviso_id = cur.lastrowid

            # Insertar fotos
            for f in fotos:
                cur.execute("INSERT INTO foto (aviso_id, ruta_archivo, nombre_archivo) VALUES (%s, %s, %s)",
                            (aviso_id, "uploads/", f))

            # Insertar contactos opcionales
            for medio, valor in contactos.items():
                cur.execute("INSERT INTO contactar_por (aviso_id, medio, id_url) VALUES (%s, %s, %s)",
                            (aviso_id, medio, valor))

        conn.commit()
        return aviso_id
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()
