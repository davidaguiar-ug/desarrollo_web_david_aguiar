-- Active: 1759259441460@@127.0.0.1@3306@tarea2
-- Crear usuario
CREATE USER 'cc5002'@'localhost' IDENTIFIED BY 'cc5002';

-- Eliminar usuario de ser necesario
DROP USER 'cc5002'@'localhost';
